
If ($true)
{
[System.Object]$objPsGalMdl = $null;
Try
{
[System.Object]$objPsGalMdl = Find-Module -Name "SnsPsScriptsMonitoring" `
-Repository "PSGallery" -ErrorAction "Stop";
} Catch {};
[System.Object[]]$arrLocMdl = @();
[System.Object[]]$arrLocMdl = Get-Module -Name "SnsPsScriptsMonitoring" -ListAvailable;
If ((-not -not "$($objPsGalMdl.Version)") -and ("$($arrLocMdl[0].Version)" -ne "$($objPsGalMdl.Version)"))
{ Write-Warning "Module ""SnsPsScriptsMonitoring"" Have Newer Version. Please Update It."; }
}

((Get-Host).UI.RawUI).WindowTitle = "SnsPsScriptsMonitoring - Created by Svetoslav Savov";
((Get-Host).UI.RawUI).BufferSize.Width = 120;
((Get-Host).UI.RawUI).BufferSize.Height = 50;
((Get-Host).UI.RawUI).WindowSize.Width = 120;
((Get-Host).UI.RawUI).WindowSize.Height = 50;
((Get-Host).UI.RawUI).MaxWindowSize.Width = 120;
((Get-Host).UI.RawUI).MaxWindowSize.Height = 50;
Initialize-SnsModuleState -DropTableIfVerificationFail:$true -DeleteOutdatedEntries:$true -Verbose:$false -Debug:$false;

If (([System.Environment]::UserInteractive) -and (-not "$($MyInvocation.PSCommandPath)"))
{
##### Generate The Warning Message
[System.String]$strMsg = '';
[System.String]$strMsg += "`r`n$('*' * 100)`r`n*$(' ' * 98)*`r`n";
[System.String]$strMsg += "*$(' ' * 28)SnsPsScriptsMonitoring - PowerShell Module$(' ' * 28)*`r`n";
[System.String]$strMsg += "*$(' ' * 37)ModuleVersion - 1.0.0.4$(' ' * 38)*`r`n*$(' ' * 98)*`r`n";
[System.String]$strMsg += "*$(' ' * 9)AUTHOR:    Svetoslav Nedyalkov Savov (svesavov@hotmail.com)$(' ' * 30)*`r`n";
[System.String]$strMsg += "*$(' ' * 9)THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK$(' ' * 9)*`r`n";
[System.String]$strMsg += "*$(' ' * 9)OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.$(' ' * 15)*`r`n";
[System.String]$strMsg += "*$(' ' * 98)*`r`n$('*' * 100)`r`n`r`n";

##### Throw The Warning
Write-Host "$($strMsg)" -ForegroundColor 'Green';

##### Reset The Variable
Remove-Variable -Force -WhatIf:$false -Confirm:$false -ErrorAction "SilentlyContinue" -Name "strMsg";
}
